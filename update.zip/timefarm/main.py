from colorama import Fore, Style, init
from timefarm import TimeFarm
import datetime
import os
import sys
import time


def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def split_chunk(var):
    if isinstance(var, int):
        var = str(var)
    n = 3
    var = var[::-1]
    return ' '.join([var[i:i + n] for i in range(0, len(var), n)])[::-1]

def main():
    init()
    tf = TimeFarm()

    with open('tokens.txt', 'r') as file:
        tokens = [line.strip() for line in file.readlines()]

    print(f"👸🏻 {Fore.CYAN + Style.BRIGHT}[ Processing {len(tokens)} Account ]")

    for index, token in enumerate(tokens, start=1):
        print(f"👸🏻 {Fore.CYAN + Style.BRIGHT}[ Account {index} ]")
        tasks = tf.tasks(token)
        balance = tf.balance(token)
        print(f"💵 {Fore.MAGENTA + Style.BRIGHT}[ Balance {split_chunk(str(int(balance['balance'])))} ]")
        for task in tasks:
            if 'submission' in task and 'status' in task['submission']:
                if task['submission']['status'] == 'CLAIMED':
                    print(f"🔖 {Fore.GREEN + Style.BRIGHT}[ {task['title']} Claimed ]")
                elif task['submission']['status'] == 'COMPLETED':
                    print(f"🔖 {Fore.BLUE + Style.BRIGHT}[ Claiming {task['title']} ]")
                    tf.claims_tasks(token, task['id'])
                    time.sleep(3)
                elif task['submission']['status'] == 'SUBMITTED':
                    print(f"🔖 {Fore.BLUE + Style.BRIGHT}[ {task['title']} Already Submitted ]")
                elif task['submission']['status'] == 'REJECTED':
                    print(f"🔖 {Fore.BLUE + Style.BRIGHT}[ {task['title']} Rejected ]")
                    tf.submissions_task(token, task['id'])
                    print(f"🔖 {Fore.YELLOW + Style.BRIGHT}[ Resubmit {task['title']} ]")
                    time.sleep(3)
            else:
                tf.submissions_task(token, task['id'])
                print(f"🔖 {Fore.YELLOW + Style.BRIGHT}[ Submitted {task['title']} ]")
                time.sleep(3)
        farming = tf.info_farming(token)
        if farming['activeFarmingStartedAt'] == None:
            start_farming = tf.start_farming(token)
            print(f"🧬 {Fore.BLUE + Style.BRIGHT}[ Started Farming ]"
                  f"{Fore.WHITE + Style.BRIGHT} | "
                  f"💰 {Fore.BLUE + Style.BRIGHT}[ Farming Reward {split_chunk(str(int(start_farming['farmingReward'])))} ]")
        else:
            start_time = datetime.datetime.fromisoformat(farming['activeFarmingStartedAt'].replace("Z", "+00:00"))
            end_time = start_time + datetime.timedelta(seconds=farming['farmingDurationInSec'])
            now = datetime.datetime.now(datetime.timezone.utc)
            remaining_time = end_time - now
            
            if remaining_time.total_seconds() > 0:
                hours, remainder = divmod(remaining_time.total_seconds(), 3600)
                minutes, seconds = divmod(remainder, 60)
                print(f"⏰ {Fore.YELLOW + Style.BRIGHT}[ Farming Finished At {int(hours)} Hours {int(minutes)} Minutes {int(seconds)} Seconds ]")
            else:
                finish_farming = tf.finish_farming(token)
                print(f"💰 {Fore.GREEN + Style.BRIGHT}[ Farming Reward {farming['farmingRward']} ]"
                  f"{Fore.WHITE + Style.BRIGHT} | "
                  f"💵 {Fore.GREEN + Style.BRIGHT}[ Balance {split_chunk(str(int(finish_farming['balance'])))} ]")
    print(f"👸🏻 {Fore.CYAN + Style.BRIGHT}[ All Account Successfully Processed ]")
    time.sleep(5)


if __name__ == "__main__":
    # TimeFarm().get_token()
    # main()
    while True:
        try:
            TimeFarm().get_token()
            main()
        except KeyboardInterrupt:
            sys.exit(0)
        except Exception as e:
            print(f"🍓 {Fore.RED+Style.BRIGHT}[ {type(e).__name__} {e} ]")
        clear()