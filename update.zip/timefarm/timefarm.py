from colorama import Fore, Style
import json
import requests


class TimeFarm:
    def __init__(self):
        self.headers = {
            'Accept': '*/*',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Host': 'tg-bot-tap.laborx.io',
            'Origin': 'https://timefarm.app',
            'Referer': 'https://timefarm.app/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)'
        }

    def get_token(self):
        url = 'https://tg-bot-tap.laborx.io/api/v1/auth/validate-init/v2'
        self.headers.update({
            'Content-Length': '359',
        })
        try:
            with open('queries.txt', 'r') as file:
                queries = file.readlines()

            for query in queries:
                query = query.strip()
                payload = {
                    "initData": query,
                    "platform": "ios"
                }

                response = requests.post(url=url, headers=self.headers, json=payload)
                response.raise_for_status()
                data = response.json()

                with open('tokens.txt', '+w') as file:
                    file.write(f"{data['token']}\n")

            return True
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def balance(self, token):
        url = 'https://tg-bot-tap.laborx.io/api/v1/balance'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}"
            })
            response = requests.get(url=url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def tasks(self, token):
        url = 'https://tg-bot-tap.laborx.io/api/v1/tasks'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}"
            })
            response = requests.get(url=url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def claims_tasks(self, token, task_id):
        url = f"https://tg-bot-tap.laborx.io/api/v1/tasks/{task_id}/claims"
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}"
            })
            response = requests.post(url=url, headers=self.headers, json={})
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def submissions_task(self, token, task_id):
        url = f"https://tg-bot-tap.laborx.io/api/v1/tasks/{task_id}/submissions"
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}",
                'Content-Length': '2'
            })
            response = requests.post(url=url, headers=self.headers, json={})
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def claims_referral(self, token):
        url = 'https://tg-bot-tap.laborx.io/api/v1/balance/referral/claim'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}",
                'Content-Length': '2'
            })
            response = requests.post(url=url, headers=self.headers, json={})
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def info_farming(self, token):
        # GET
        #     "balance": "1266900.000",
        #     "activeFarmingStartedAt": null,
        #     "farmingDurationInSec": 14400,
        #     "farmingReward": 14400
        # }
        url = 'https://tg-bot-tap.laborx.io/api/v1/farming/info'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}"
            })
            response = requests.get(url=url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def start_farming(self, token):
        # POST
        # {
        #     "balance": "1266900.000",
        #     "activeFarmingStartedAt": "2024-07-17T04:38:02.005Z",
        #     "farmingDurationInSec": 14400,
        #     "farmingReward": 14400
        # }
        url = 'https://tg-bot-tap.laborx.io/api/v1/farming/start'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}",
                'Content-Length': '2'
            })
            response = requests.post(url=url, headers=self.headers, json={})
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def finish_farming(self, token):
        # POST
        # {
        #     "balance": 1252500,
        #     "referral": {
        #         "availableBalance": 0,
        #         "claimedBalance": 202500
        #     }
        # }
        url = 'https://tg-bot-tap.laborx.io/api/v1/farming/finish'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}",
                'Content-Length': '2'
            })
            response = requests.post(url=url, headers=self.headers, json={})
            response.raise_for_status()
            return response.json()
        except (json.JSONDecodeError, requests.RequestException, Exception) as e:
            return print(f"🍓 {Fore.RED+Style.BRIGHT}[ {e} ]")

    def daily_questions(self, token, answer):
        # GET
        # {
        #     "title": "Question of the day:",
        #     "description": "When did LaborX, the blockchain-based freelancer platform, officially launch?",
        #     "date": "2024-07-17",
        #     "reward": 100000,
        #     "answer": {
        #         "value": "15/11/2018",
        #         "isCorrect": true,
        #         "rewardAssigned": 100000
        #     }
        # }
        # POST
        # {
        #     "isCorrect": true
        # }
        # POST Payload
        # {
        #     "answer": "15/11/2018"
        # }
        url = 'https://tg-bot-tap.laborx.io/api/v1/daily-questions'
        try:
            self.headers.update({
                'Authorization': f"Bearer {token}",
                'Content-Length': '23'
            })
            payload = {
                'answer': answer
            }
            response = requests.post(url=url, headers=self.headers, json=payload)
            response.raise_for_status()
            return response.json()
        except:
            return None