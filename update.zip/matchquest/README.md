
# MatchQuest / Matchain
MatchQuest BOT

Register Here : [MatchQuest](https://t.me/MatchQuestBot/start?startapp=9e5c191bf7558fd0e06d4b8ea7741fae)


## Features

- Auto Farming
- Auto Claim
- Auto Claim Invite Point
- Auto Playgame With 3 Mode (Max. Score, Random Score, Default Score)
- Auto Clear and Claim Task
- Auto Get token
- Multi Account

## Installation

Install with python

1. Download Python 3.10+
2. Install Module (pip install requests colorama)
3. Buka Bot Matchquest di PC (Telegram Web)
4. Jika sudah terbuka > Klik kanan Inspect
5. Di Application > Session Storage > https://tgapp.matchain.io
6. __telegram__initParams ambil tgwebappdata "query_idxxxx" atau "user_id=" tanpa kutip 
7. Paste di data.txt
8. python match.py

 

![SS](https://i.ibb.co.com/4j01D6v/Cuplikan-layar-2024-07-02-134708.png)